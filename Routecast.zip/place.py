class Place:
    def __init__(self):
        self.name = None
        self.temp = None
        self.clouds = None
        self.x = None
        self.y = None
